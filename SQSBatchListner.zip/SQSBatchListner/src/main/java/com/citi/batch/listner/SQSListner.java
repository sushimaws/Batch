/**
 * 
 */
package com.citi.batch.listner;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
/**
 * @author sushim
 *`
 */
@Component
public class SQSListner {
	private final static Log log = LogFactory.getLog(SQSListner.class);
	
	@Value("${sqs.url}")
	private String sqsURL;

	@Scheduled(fixedRate = 1000)
	public void getMessage() {
		final AmazonSQS sqs = AmazonSQSClientBuilder.defaultClient();
        while(true) {
        	log.info("Receiving messages from MyQueue.\n");
        	final ReceiveMessageRequest receiveMessageRequest =
                    new ReceiveMessageRequest(sqsURL)
                    	.withMaxNumberOfMessages(1)
                    	.withWaitTimeSeconds(3);
	        final List<com.amazonaws.services.sqs.model.Message> messages = sqs.receiveMessage(receiveMessageRequest)
	                .getMessages();
	        for (final com.amazonaws.services.sqs.model.Message message : messages) {
	        	log.debug("Message");
	        	log.debug("  MessageId:     "
	                    + message.getMessageId());
	        	log.debug("  ReceiptHandle: "
	                    + message.getReceiptHandle());
	        	log.debug("  MD5OfBody:     "
	                    + message.getMD5OfBody());
	        	log.debug("  Body:          "
	                    + message.getBody());
	            if(!"".equals(message.getBody())) {
		            final String messageReceiptHandle = messages.get(0).getReceiptHandle();
		            sqs.deleteMessage(new DeleteMessageRequest(sqsURL,
		                    messageReceiptHandle));
		         }
	        }
        }
	}
}
