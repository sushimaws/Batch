/**
 * 
 */
package com.citi.batch.util;

import java.util.UUID;

/**
 * @author sushim
 *
 */
public class CommonUtils {
	public static String makeRandomString(int sizeByte) {
		return UUID.randomUUID().toString();
	}
}
