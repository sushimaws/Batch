/**
 * 
 */
package com.citi.batch.consumer;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;

/**
 * @author sushim
 *
 */
@Component
public class Consumer extends Thread {
	private final static Log log = LogFactory.getLog(Consumer.class);
	final AmazonSQS sqsClient;
	final String queueUrl;
	final AtomicInteger consumedCount;
	final AtomicBoolean stop;

	public Consumer(AmazonSQS sqsClient, String queueUrl, AtomicInteger consumedCount, AtomicBoolean stop) {
		this.sqsClient = sqsClient;
		this.queueUrl = queueUrl;
		this.consumedCount = consumedCount;
		this.stop = stop;
	}

	/*
	 * Each consumer thread receives and deletes messages until the main thread
	 * stops the consumer thread. The consumedCount object tracks the number of
	 * messages that are consumed by all consumer threads, and the count is logged
	 * periodically.
	 */
	public void run() {
		try {
			while (!stop.get()) {
				try {
					final ReceiveMessageResult result = sqsClient
							.receiveMessage(new ReceiveMessageRequest(queueUrl));

					if (!result.getMessages().isEmpty()) {
						final Message m = result.getMessages().get(0);
						sqsClient.deleteMessage(new DeleteMessageRequest(queueUrl, m.getReceiptHandle()));
						consumedCount.incrementAndGet();
					}
				} catch (AmazonClientException e) {
					log.error(e.getMessage());
				}
			}
		} catch (AmazonClientException e) {
			/*
			 * By default, AmazonSQSClient retries calls 3 times before failing. If this
			 * unlikely condition occurs, stop.
			 */
			log.error("Consumer: " + e.getMessage());
			System.exit(1);
		}
	}

}
