/**
 * 
 */
package com.citi.batch.monitor;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.citi.batch.producer.BatchProducer;

/**
 * @author sushim
 *
 */
@Component
public class Monitor extends Thread{

	private final static Log log = LogFactory.getLog(BatchProducer.class);
	
	private final AtomicInteger producedCount;
	private final AtomicInteger consumedCount;
	private final AtomicBoolean stop;

	public Monitor(AtomicInteger producedCount, AtomicInteger consumedCount, AtomicBoolean stop) {
		this.producedCount = producedCount;
		this.consumedCount = consumedCount;
		this.stop = stop;
	}

	public void run() {
		try {
			while (!stop.get()) {
				Thread.sleep(1000);
				log.info("produced messages = " + producedCount.get() + ", consumed messages = "
						+ consumedCount.get());
			}
		} catch (InterruptedException e) {
			// Allow the thread to exit.
		}
	}

}
