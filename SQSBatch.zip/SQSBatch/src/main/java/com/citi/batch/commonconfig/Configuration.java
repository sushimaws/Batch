/**
 * 
 */
package com.citi.batch.commonconfig;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.GetQueueUrlRequest;
import com.citi.batch.consumer.BatchConsumer;
import com.citi.batch.consumer.Consumer;
import com.citi.batch.producer.BatchProducer;
import com.citi.batch.producer.Producer;

/**
 * @author sushim
 *
 */
@Component
public class Configuration {

	@Value("queueName")
	public static String queueName = "BulkMessage";

	@Value("producerCount")
	public static int producerCount = 5;

	@Value("consumerCount")
	public static int consumerCount = 50;

	@Value("batchSize")
	public static int batchSize = 10;

	@Value("messageSizeByte")
	public static int messageSizeByte = 1;

	@Value("runTimeMinutes")
	public static int runTimeSecond=5;

	// The maximum runtime of the program.
	private final static int MAX_RUNTIME_SECOUND = 5;
	private final static Log log = LogFactory.getLog(Configuration.class);

	public static void main(String[] args) throws InterruptedException {

		/*
		 * Create a new instance of the builder with all defaults (credentials and
		 * region) set automatically. For more information, see Creating Service Clients
		 * in the AWS SDK for Java Developer Guide.
		 */
		final ClientConfiguration clientConfiguration = new ClientConfiguration()
				.withMaxConnections(producerCount + consumerCount);

		final AmazonSQS sqsClient = AmazonSQSClientBuilder.standard().withRegion(Regions.US_EAST_1.getName())
				.withClientConfiguration(clientConfiguration).build();

		final String queueUrl = sqsClient.getQueueUrl(new GetQueueUrlRequest(queueName)).getQueueUrl();

		// The flag used to stop producer, consumer, and monitor threads.
		final AtomicBoolean stop = new AtomicBoolean(false);

		// Start the producers.
		/*
		 * final AtomicInteger producedCount = new AtomicInteger(); final Thread[]
		 * producers = new Thread[producerCount]; for (int i = 0; i < producerCount;
		 * i++) { if (batchSize == 1) { producers[i] = new Producer(sqsClient, queueUrl,
		 * messageSizeByte, producedCount, stop); } else { producers[i] = new
		 * BatchProducer(sqsClient, queueUrl, batchSize, messageSizeByte, producedCount,
		 * stop); } producers[i].start(); }
		 * 
		 * 
		 * for (int i = 0; i < producerCount; i++) { producers[i].join(); }
		 */
		
		 // Start the consumers.
        final AtomicInteger consumedCount = new AtomicInteger();
        final Thread[] consumers = new Thread[consumerCount];
        for (int i = 0; i < consumerCount; i++) {
            if (batchSize == 1) {
                consumers[i] = new Consumer(sqsClient, queueUrl, consumedCount,
                        stop);
            } else {
                consumers[i] = new BatchConsumer(sqsClient, queueUrl, batchSize,
                        consumedCount, stop);
            }
            consumers[i].start();
        }
		
        // Wait for the specified amount of time then stop.
        Thread.sleep(TimeUnit.SECONDS.toMillis(Math.min(runTimeSecond,
        		MAX_RUNTIME_SECOUND)));
        stop.set(true);
	}

	

}